import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchBox extends BeyAnaPage {
   By searchBoxLocator=By.id("searchKey");
   By submitButtonLocator=By.id("searchKey");
    public SearchBox(WebDriver driver){
        super(driver);
    }

    public void search(String text) {
type(searchBoxLocator,text);
click(submitButtonLocator);
    }
}
