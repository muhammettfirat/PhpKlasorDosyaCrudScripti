import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BeyAnaPage {
    SearchBox searchBox;
By cardCountLocator = By.id("o-header__userInfo--count");
By cardContainerLocator=By.id("o-header__userInfo--text");
    public  HomePage(WebDriver driver){
        super(driver);
        searchBox=new SearchBox(driver);
    }

    public SearchBox searchBox() {
    return this.searchBox;
    }

    public boolean isProductCountup() {
        return getCartCount()>0;
    }

    public void goToCard() {
        click(cardContainerLocator);

    }
    private int getCartCount(){
     String count=  find(cardCountLocator).getText();
       return Integer.parseInt(count);
    }
}
