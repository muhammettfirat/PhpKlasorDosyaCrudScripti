import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductDetailPage extends BeyAnaPage{
    By addToSizeLocator=By.id("m-variation__item -disabled");
    By addToCardButtonLocator=By.id("addBasket");

    public ProductDetailPage(WebDriver driver){
        super(driver);
    }

    public boolean isOnProductDetailPage() {
        return isDisplayed(addToCardButtonLocator);
    }
private boolean isOnSizePage(){
        return isDisplayed(addToSizeLocator);
}
    public void addToCard() {
        click(addToCardButtonLocator);
        click(addToSizeLocator);
    }
}
